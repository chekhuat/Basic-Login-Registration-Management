<?php
	session_start();
		require 'config/server.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<title>JSS</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		
	</head>
	<body>
		
		<div class="jumbotron col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3 ">
			<h1 class="text-center">Welcome to JSS!</h1>
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3">
				<form method="post" action=" homepage.php">
					<button name="remove" class="btn btn-primary col-lg-12 col-md-12 col-sm-12 col-xs-12" role="button">Remove Account</button>
				</form>
				<button name="edit" class="btn btn-primary edit col-lg-12 col-md-12 col-sm-12 col-xs-12" onclick="myFunction(this)" role="button">Edit Account</button>
				<button class="btn btn-danger  col-lg-12 col-md-12 col-sm-12 col-xs-12" onclick="location.href='index.php';">Logout</button>
			
			</div>
			
			<br><br>
			
			<img src="img/Koala.jpg" class="img-circle col-lg-6 col-md-6 col-sm-6 col-xs-6 col-lg-offset-3 col-md-offset-3 col-sm-offset-3 col-xs-offset-3 ">
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<div class="row text-center col-lg-12 col-md-12 col-sm-12 col-xs-12" id="myDIV2">
				<?php
				$result = mysqli_query($con,"select * from infor where username='".$_SESSION['username']."'");
				if (!$result) {
					exit;
				}
					$row=mysqli_fetch_row($result);
					echo "<h2 class='text-center'>Welcome, ".$row[3]."!!</h2>";
					echo "<p class='text-center'>Name: ".$row[0]."</p>";
					echo "<p class='text-center'>Age: ".$row[1]."</p>";
					echo "<p class='text-center'>Gender: ".$row[2]."</p>" ;
				?>
			</div>
			<?php
				
				if (isset($_POST['remove']))
					{
						$sqlquery_run=mysqli_query($con,"delete from infor where username='".$_SESSION['username']."'");
						if($sqlquery_run){
						header('location:index.php');
						echo '<script type="text/javascript">alert("Account Deleted!")</script>';

						} else{
						echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
						}
					}
			?>
			<div class="jumbotron" >
				<form class="toHide" id="myDIV" method="post" action="homepage.php">
					<div class="form-group">
						<label>Old Password</label>
						<input name="opassword" type="Password" class="form-control" placeholder="Password" aria-describedby="basic-addon2" required>
					</div>
					<div class="form-group">
						<label>New Password</label>
						<input name="password" type="Password" class="form-control" placeholder="Password" aria-describedby="basic-addon2" required>
					</div>
					<div class="form-group">
						<label>Confirm New Password</label>
						<input name="cpassword" type="Password" class="form-control" placeholder="Confirm Password" aria-describedby="basic-addon2" required>
					</div>
					<div class="text-right">
						<button name="change" class="btn btn-primary" role="button">Change Password</button>
						
					</div>
				</form>
			</div>

			<?php 
			if (isset($_POST['change']))
					 {
						$opassword = $_POST['opassword'];
						$password = $_POST['password'];
						$cpassword = $_POST['cpassword'];


						$result = mysqli_query($con,"select * from infor where username='".$_SESSION['username']."'");
						if (!$result) {
							exit;
						}
							$row=mysqli_fetch_row($result);
							$oldpass= $row[4];

						if($opassword==$oldpass)
						{
							if($password==$cpassword)
							{
								$sqlquery= "update infor set password='$cpassword' where username='$row[3]'";
								$sqlquery_run=mysqli_query($con,$sqlquery);
								echo '<script type="text/javascript">alert("Password Changed!")</script>';

							}

							else						 
							{
								echo '<script type="text/javascript">alert("New Password doesnt matched!")</script>';								
							}
						}
						else {
							echo '<script type="text/javascript">alert("Wrong Password!")</script>';
						}

					}


			 ?>
			
		</div>
		
		
	</div>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/js.js"></script>
</body>
</html>