<?php
	session_start();
	require 'config/server.php';

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Basic Login</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body> 
		<div class="container col-md-offset-3 col-md-6">
			<div class="jumbotron">
				<form class="myform" action="index.php" method="post">
					<h2 class="text-center">Welcome to JSS!</h2><br>
					<label>Username</label>
					<div class="input-group">	
						<input name="username" type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon2">
						<span class="input-group-addon glyphicon glyphicon-user" id="basic-addon2"></span>
					</div> <br>	
					<label>Password</label>
					<div class="input-group">
						<input name="password" type="password" class="form-control" placeholder="Password" aria-describedby="basic-addon2">
						<span class="input-group-addon glyphicon glyphicon-lock" id="basic-addon2"></span>
					</div> <br>	
					<div class="text-right">
						<a href="#"><button name="login" class="btn btn-primary" role="button">Login</button></a>
						<br><br>
						<small>New to JSS? <a href="register.php">Sign up now >></a></small>
					</div>

					
					
				</form>
				<?php 
				if (isset($_POST['login']))
				{
					$username=$_POST['username'];
					$password=$_POST['password'];

					$sqlquery="select * from infor where username='$username' and password='$password'";
					$sqlquery_run=mysqli_query($con,$sqlquery);

					if(mysqli_num_rows($sqlquery_run)>0)
					{
						echo '<script type="text/javascript">alert("You are now logged in!")</script>';

						$_SESSION['username']=$username;
						header('location:homepage.php');

						$_SESSION['password']=$password;
						header('location:homepage.php');					}
					else
					{
						echo '<script type="text/javascript">alert("You are not regsiterd!")</script>';
					}
				}

				 ?>

			</div>
		</div>
		<!-- <script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/jquery.min.js"></script> -->
	</body>
</html>