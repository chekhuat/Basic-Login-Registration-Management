<?php
	
	require 'config/server.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Basic Login</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body> 
		<div class="container col-md-offset-3 col-md-6">
			<div class="jumbotron">
				<form class="myform" action="register.php" method="post">
					<h2 class="text-center">Welcome to JSS!</h2><br>
					<div class="form-group">	
						<label>Name</label>
						<input name="name" type="text" class="form-control" placeholder="Name" aria-describedby="basic-addon2" required>
					</div>
					<div class="form-group">
						<label>Age</label>
						<input name="age" type="text" class="form-control" placeholder="Age" aria-describedby="basic-addon2" required>
					</div>
					<div class="form-group">
						<label>Gender</label>
						<input name="gender" type="text" class="form-control" placeholder="Gender" aria-describedby="basic-addon2" required>
					</div>
					<div class="form-group">
						<label>Username</label>
						<input name="username" type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon2" required>
					</div> 
					
					<div class="form-group">
						<label>Password</label>
						<input name="password" type="Password" class="form-control" placeholder="Password" aria-describedby="basic-addon2" required>
					</div>
					<div class="form-group">
	 					<label>Confirm Password</label>
						<input name="cpassword" type="Password" class="form-control" placeholder="Confirm Password" aria-describedby="basic-addon2" required>
					</div>
					<div class="text-right">
						<button name="register" class="btn btn-primary" role="button">Register</button>
						<br>
						<small>Cancel Registration? <a href="index.php">Back to Home >></a></small>
						
					</div>					
				</form>

				<?php 
					if (isset($_POST['register']))
					 {
						// echo '<script type="text/javascript"> alert ("Register button clicked") </script>';

						$name = $_POST['name'];
						$age = $_POST['age'];
						$gender = $_POST['gender'];
						$username = $_POST['username'];
						$password = $_POST['password'];
						$cpassword = $_POST['cpassword'];

						if($password==$cpassword)
						{
							$sqlquery= "select * from infor where username='$username'";
							$sqlquery_run=mysqli_query($con,$sqlquery);

							if((mysqli_num_rows($sqlquery_run))>0)
							{
								echo '<script type="text/javascript">alert("Username already taken. Try another one!")</script>';
							}

							else						 
							{
								$sqlquery="insert into infor values ('$name','$age','$gender','$username','$password')";
								$sqlquery_run=mysqli_query($con,$sqlquery);

								if ($sqlquery_run)
								{
									echo '<script type="text/javascript">alert("Registration Complete! You can now login.")</script>';
								}
								else 
								{
									echo '<script type="text/javascript">alert("Registration cannot be processed.")</script>';
								}
							}
						}
						else {
							echo '<script type="text/javascript">alert("Password confirmation mismatched!")</script>';
						}

					}
				?>

			</div>
		</div>
		<!-- <script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/jquery.min.js"></script>
	 --></body>
</html>