function myFunction() {
    var x = document.getElementById("myDIV");
    var y = document.getElementById("myDIV2");
    if (x.style.display === "inline") {
        x.style.display = "none";
        y.style.display = "inline";
    } else {
        x.style.display = "inline";
        y.style.display = "none";
    }
}